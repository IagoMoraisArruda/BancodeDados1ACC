package br.edu.unifesspa.acc.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

/**
 * Contrato basico de CRUD que cada DAO concreto implementa com SQL escrito a mao
 * (sem ORM), usando PreparedStatement para evitar SQL Injection.
 */
public interface Dao<T, ID> {

    T save(T entity) throws SQLException;

    Optional<T> findById(ID id) throws SQLException;

    List<T> findAll() throws SQLException;

    boolean update(T entity) throws SQLException;

    boolean deleteById(ID id) throws SQLException;
}
