package br.edu.unifesspa.acc.connection;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Fabrica de conexoes JDBC puras (sem ORM) para o Azure Database for MySQL.
 *
 * Le as credenciais de src/main/resources/application.properties e monta
 * a connection string no formato exigido pelo Azure, incluindo SSL.
 *
 * Cada chamada a getConnection() devolve uma conexao nova; quem chama e
 * responsavel por fechar (try-with-resources), como e feito nos DAOs.
 */
public final class ConnectionFactory {

    private static final Properties CONFIG = new Properties();

    static {
        try (InputStream input = ConnectionFactory.class
                .getClassLoader()
                .getResourceAsStream("application.properties")) {

            if (input == null) {
                throw new IllegalStateException(
                        "application.properties nao encontrado em src/main/resources");
            }
            CONFIG.load(input);

            // Registra o driver explicitamente (JDBC 4+ tambem faz autoload,
            // mas deixamos explicito por clareza didatica).
            Class.forName("com.mysql.cj.jdbc.Driver");

        } catch (IOException e) {
            throw new IllegalStateException("Erro ao ler application.properties", e);
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("Driver JDBC do MySQL nao encontrado no classpath", e);
        }
    }

    private ConnectionFactory() {
        // classe utilitaria, nao deve ser instanciada
    }

    public static Connection getConnection() throws SQLException {
        String host = CONFIG.getProperty("db.host");
        String port = CONFIG.getProperty("db.port");
        String name = CONFIG.getProperty("db.name");
        String user = CONFIG.getProperty("db.user");
        String password = CONFIG.getProperty("db.password");
        boolean useSSL = Boolean.parseBoolean(CONFIG.getProperty("db.useSSL", "true"));

        String url = String.format(
                "jdbc:mysql://%s:%s/%s?useSSL=%s&requireSSL=%s&serverTimezone=America/Belem",
                host, port, name, useSSL, useSSL
        );

        return DriverManager.getConnection(url, user, password);
    }
}
