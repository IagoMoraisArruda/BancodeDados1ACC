# Sistema de Gestão de ACC — Camada de Persistência (Java + JDBC + Azure)

Projeto Java puro (sem Spring, sem JPA, sem Hibernate) para o **Produto 2** da
disciplina Banco de Dados I — Tema 2 (Sistema de Gestão de ACC).

## Por que este stack

- **JDBC puro**: o enunciado veda explicitamente ORMs (item 3.2). Toda consulta
  é escrita à mão em `PreparedStatement`, o que também facilita explicar o SQL
  na arguição.
- **Azure Database for MySQL Flexible Server**: o `Diagrama_V5.mwb` já é um
  schema MySQL 3FN pronto (10 tabelas, com FKs). Hospedando em MySQL na Azure,
  você aproveita o schema exportado do Workbench sem converter dialeto SQL.

## 1. Criar o servidor no Azure

1. No [Portal Azure](https://portal.azure.com), crie um recurso
   **Azure Database for MySQL Flexible Server** (camada Burstable B1ms é
   suficiente e mais barata para um projeto acadêmico).
2. Defina usuário administrador e senha (guarde bem, você vai usar no
   `application.properties`).
3. Em **Networking**, habilite "Allow public access from any Azure service"
   e adicione seu IP atual às regras de firewall (senão a conexão da sua
   máquina será recusada).
4. Anote o **Server name** (algo como
   `acc-facsi-server.mysql.database.azure.com`).

## 2. Criar o schema a partir do seu .mwb

No MySQL Workbench, use **Database > Forward Engineer** apontando para o
servidor Azure (host, porta 3306, usuário e senha do passo 1) para gerar as
10 tabelas (Curso, Aluno, PeriodoLetivo, CategoriaAcc, TipoACC, AtividadeACC,
Documento, Instituicao, Professor, Validacao) diretamente na nuvem.

## 3. Configurar o projeto Java

Copie o template e preencha com os dados reais (o arquivo real fica fora do
Git, veja `.gitignore`):

```bash
cp src/main/resources/application.properties.example src/main/resources/application.properties
```

Edite `src/main/resources/application.properties`:

```properties
db.host=acc-facsi-server.mysql.database.azure.com
db.port=3306
db.name=acc_facsi
db.user=admin_acc
db.password=sua_senha_aqui
db.useSSL=true
```

A Azure exige SSL por padrão para conexões externas — por isso
`ConnectionFactory` já monta a URL JDBC com `useSSL=true&requireSSL=true`.

## 4. Rodar

```bash
mvn clean package
java -jar target/acc-persistence-jar-with-dependencies.jar
```

## Estrutura

```
src/main/java/br/edu/unifesspa/acc/
├── model/        # 10 POJOs, um por tabela do Diagrama_V5.mwb
├── connection/    # ConnectionFactory (JDBC puro, le application.properties)
├── dao/           # CRUD (Dao<T,ID>) + consultas gerenciais do TEMA 2
└── app/Main.java  # demonstração de uso
```

## Cobertura das consultas gerenciais exigidas (item 4.2 do enunciado)

| Requisito do enunciado                                   | Onde está implementado                          |
|------------------------------------------------------------|--------------------------------------------------|
| Alunos que atingiram a pontuação mínima (51 pts)           | `AlunoDAO.findAlunosComPontuacaoMinimaAtingida`  |
| Alunos com pendências                                       | `ValidacaoDAO.findAlunosComPendencias`           |
| Categorias de atividade mais frequentes                     | `ConsultasGerenciaisDAO.findCategoriasMaisFrequentes` |
| Certificados apresentados por um aluno                      | `DocumentoDAO.findCertificadosPorAluno`          |
| Pontuação acumulada por discente                             | `ValidacaoDAO.findPontuacaoAcumulada`            |
| Atividades aguardando validação                              | `AtividadeACCDAO.findAtividadesAguardandoValidacao` |
| Tipos de ACC com maior volume de participação                | `TipoACCDAO.findVolumeParticipacaoPorTipo`       |
| *(extra)* Carga horária aprovada por aluno                   | `ConsultasGerenciaisDAO.findCargaHorariaAprovadaPorAluno` |
| *(extra)* Atividades validadas por professor                  | `ConsultasGerenciaisDAO.findAtividadesValidadasPorProfessor` |
| *(extra)* Instituições com mais documentos emitidos            | `ConsultasGerenciaisDAO.findInstituicoesComMaisDocumentos` |
| *(extra)* Distribuição de atividades por período letivo         | `ConsultasGerenciaisDAO.findAtividadesPorPeriodoLetivo` |

11 consultas ao todo — acima do mínimo de 10 pedido no item 3.2.

## O que falta você mesmo ajustar

- Os nomes de enum (`TipoCategoria`, `TipoDocumento`, `TipoEntidade`,
  `StatusValidacao`) foram lidos direto do seu `.mwb` — confira se batem com o
  que o grupo decidiu no documento descritivo de hipóteses de modelagem.
- Não incluí uma camada de "Service"/regra de negócio (ex.: validar se a soma
  de pontos não excede `PontuacaoMaxima` do TipoACC) — isso fica a critério do
  grupo, mas recomendo criar antes da apresentação.
