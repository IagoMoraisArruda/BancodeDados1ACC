# Guia: subir o banco na Azure (Azure CLI)

Dois caminhos: pelo **Portal** (clicando) ou pelo **Azure CLI** (comandos).
Abaixo os comandos, que são reproduzíveis e mais rápidos de repetir se algo
der errado.

Pré-requisito: `az login` já feito (ou use o Cloud Shell no portal.azure.com,
que já vem logado).

## 1. Criar grupo de recursos e o servidor MySQL

```bash
# Grupo de recursos (pasta lógica pros recursos do projeto)
az group create \
  --name rg-acc-facsi \
  --location brazilsouth

# Servidor MySQL Flexible Server (camada mais barata: Burstable B1ms)
az mysql flexible-server create \
  --resource-group rg-acc-facsi \
  --name acc-facsi-server \
  --location brazilsouth \
  --admin-user admin_acc \
  --admin-password "TrocarEstaSenh@123!" \
  --sku-name Standard_B1ms \
  --tier Burstable \
  --storage-size 32 \
  --version 8.0.21 \
  --public-access 0.0.0.0-255.255.255.255
```

O `--public-access 0.0.0.0-255.255.255.255` libera acesso de qualquer IP —
prático para desenvolvimento/apresentação do trabalho, mas **restrinja depois**
com `az mysql flexible-server firewall-rule create` se for manter o servidor
no ar por mais tempo.

## 2. Criar o schema (banco de dados) dentro do servidor

```bash
az mysql flexible-server db create \
  --resource-group rg-acc-facsi \
  --server-name acc-facsi-server \
  --database-name acc_facsi
```

## 3. Gerar o SQL a partir do seu Diagrama_V5.mwb

No MySQL Workbench, com o `Diagrama_V5.mwb` aberto:

`Database` → `Forward Engineer...` → siga o assistente escolhendo:
- **Connection**: crie uma nova conexão apontando para
  `acc-facsi-server.mysql.database.azure.com`, porta 3306, usuário
  `admin_acc`, marcando "Use SSL" (aba SSL da conexão).
- **Schema**: `acc_facsi` (o que você criou no passo 2).
- Deixe marcado "Export MySQL Table Objects" e "Generate INSERT
  Statements for Tables" se quiser popular dados de teste.

Isso cria as 10 tabelas direto no servidor Azure, sem precisar rodar `.sql`
manualmente.

**Alternativa via linha de comando**, se preferir exportar o `.sql` primeiro
(`File > Export > Forward Engineer SQL CREATE Script` no Workbench) e depois
rodar:

```bash
mysql -h acc-facsi-server.mysql.database.azure.com \
      -u admin_acc -p \
      --ssl-mode=REQUIRED \
      acc_facsi < schema.sql
```

## 4. Testar a conexão antes de rodar o Java

```bash
mysql -h acc-facsi-server.mysql.database.azure.com \
      -u admin_acc -p \
      --ssl-mode=REQUIRED \
      -e "SHOW TABLES;" acc_facsi
```

Se listar as 10 tabelas, a conexão está OK e o `application.properties` do
projeto Java vai funcionar com os mesmos dados.

## 5. Apagar tudo depois da apresentação (evitar cobrança)

```bash
az group delete --name rg-acc-facsi --yes --no-wait
```

Isso remove o servidor MySQL e qualquer outro recurso criado no grupo, de
uma vez só.
